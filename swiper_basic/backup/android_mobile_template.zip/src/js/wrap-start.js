(function () {
    'use strict';
    var $;