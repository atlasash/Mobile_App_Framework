	return Swiper;
}));